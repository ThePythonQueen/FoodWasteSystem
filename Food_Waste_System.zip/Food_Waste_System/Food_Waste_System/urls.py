
from django.conf.urls import url
from django.contrib import admin

from Food.views import *

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^$', User_panel,name='user_panel'),
    url(r'^login/', Login,name='login'),
    url(r'^signup/', SignUp,name='signup'),
    url(r'^logout/', Logout,name='logout'),
    url(r'^home/', Home,name='home'),
    url(r'^delivery/', Delivery,name='delivered'),
url(r'^food_details/(?P<hid>[0-9]+)/',Food_details,name='food_details'),
url(r'^Take_food/(?P<fid>[0-9]+)/',Take_food,name='take_food'),
url(r'^delete/(?P<fid>[0-9]+)/',Delete,name='delete'),
   ]
