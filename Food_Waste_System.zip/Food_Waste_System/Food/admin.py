from django.contrib import admin
from .models import *
# Register your models here.


admin.site.register(Hotel_data)
admin.site.register(Food_deliver)
admin.site.register(Food_taker)