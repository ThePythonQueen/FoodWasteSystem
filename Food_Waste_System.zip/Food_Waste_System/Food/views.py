from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import login,logout,authenticate
from .models import *

def Login(request):
    error = False
    if request.method == "POST":
        d = request.POST
        u = d['user']
        p = d['pwd']
        user = authenticate(username = u,password = p)
        if user:
            login(request,user)
            if not user.is_staff:
              return redirect('home')
        else:
            error = True
    return render(request,'login_signup.html',{"error":error})

def Logout(request):
    logout(request)
    return redirect('login')

################################## Hotel Functions ###########################
def SignUp(request):
    error = False
    if request.method == "POST":
        d = request.POST
        username = d['user']
        password = d['pwd']
        hotel_name = d['hname']
        owner_name = d['oname']
        mobile = d['mob']
        address = d['add']
        u = User.objects.filter(username=username)
        if u:
            error = True
        else:
            usr = User.objects.create(username=username,password=password)
            Hotel_data.objects.create(usr = usr,name = hotel_name,owner_name = owner_name,
                                      owner_mob = mobile,address=address)
            return redirect('login')

    return render(request,'login_signup.html',{"error":error})



def Home(request):
    if not request.user.is_authenticated() or request.user.is_staff:
        return redirect('login')
    data = Hotel_data.objects.filter(usr = request.user).first()
    pending_food = Food_deliver.objects.filter(hotel=data,status = False)
    if request.method == "POST":
        food = request.POST['food']
        Food_deliver.objects.create(hotel =data,food = food)
    return render(request,'index.html',{"data":data,"pending_food":pending_food})

def Delivery(request):
    if not request.user.is_authenticated() or request.user.is_staff:
        return redirect('login')
    data = Hotel_data.objects.filter(usr=request.user).first()
    dlivered_food = Food_deliver.objects.filter(hotel=data,status = True)
    return render(request,'delivery.html',{"data":data,"dlivered_food":dlivered_food})


################################### Food Taker Functions ####################


def User_panel(request):
    all_data = Hotel_data.objects.all()
    li = []
    for i in all_data:
        for j in i.food_deliver_set.all():
            if j.status == False:
                li.append(i.id)
    return render(request,'user_panel.html',{"all_data":all_data,"li":li})


def Food_details(request,hid):
    data = Hotel_data.objects.filter(id = hid).first()
    data2 = Food_deliver.objects.filter(hotel = data,status = False)
    return render(request,'food_details.html',{"all_food":data2,"data":data})


def Take_food(request,fid):
    data = Food_deliver.objects.filter(id = fid).first()
    data2 = Hotel_data.objects.filter(id = data.hotel.id).first()
    if request.method == "POST":
        d = request.POST

        taker_name = d['name']
        mobile = d['mob']
        address = d['add']
        Food_taker.objects.create(hotel = data2,food_deliver = data,name = taker_name,
                                  mobile = mobile,address= address)
        data.status = True
        data.save()
        return redirect('food_details',data2.id)

    return render(request,'take_food.html',{"data":data2,"food_type":data.food_type})

def Delete(request,fid):
    data = Food_deliver.objects.filter(id = fid).first()
    data.delete()
    return redirect('home')